#if defined(_MSC_VER) && (_MSC_VER >= 1400) 
#pragma warning(disable : 4996) 
#endif

// The internal types
typedef unsigned char		Bit8u;
typedef signed char			Bit8s;
typedef unsigned short		Bit16u;
typedef signed short		Bit16s;
typedef unsigned long		Bit32u;
typedef signed long			Bit32s;
typedef unsigned __int64	Bit64u;
typedef signed __int64		Bit64s;
typedef unsigned int		Bitu;
typedef signed int			Bits;

